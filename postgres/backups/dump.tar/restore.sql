--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 15.1
-- Dumped by pg_dump version 15.1

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE "vue-db";
--
-- Name: vue-db; Type: DATABASE; Schema: -; Owner: -
--

CREATE DATABASE "vue-db" WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE_PROVIDER = libc LOCALE = 'en_US.utf8';


\connect -reuse-previous=on "dbname='vue-db'"

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: public; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA public;


--
-- Name: SCHEMA public; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON SCHEMA public IS 'standard public schema';


--
-- Name: action; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.action AS ENUM (
    'read',
    'create',
    'update',
    'delete'
);


--
-- Name: clearance; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.clearance AS ENUM (
    'denied',
    'if_owned',
    'allowed'
);


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.accounts (
    login text NOT NULL,
    password text NOT NULL,
    email text NOT NULL,
    user_id integer,
    active boolean DEFAULT false NOT NULL
);


--
-- Name: departments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.departments (
    dep_id integer NOT NULL,
    name text NOT NULL
);


--
-- Name: departments_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.departments_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: departments_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.departments_id_seq OWNED BY public.departments.dep_id;


--
-- Name: permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.permissions (
    perm_id integer NOT NULL,
    table_name text NOT NULL,
    clearance public.clearance NOT NULL,
    system_role integer NOT NULL,
    action public.action NOT NULL
);


--
-- Name: permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.permissions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: permissions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.permissions_id_seq OWNED BY public.permissions.perm_id;


--
-- Name: positions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.positions (
    pos_id integer NOT NULL,
    name text NOT NULL
);


--
-- Name: positions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.positions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: positions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.positions_id_seq OWNED BY public.positions.pos_id;


--
-- Name: project_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_roles (
    proj_role_id integer NOT NULL,
    name text NOT NULL
);


--
-- Name: project_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.project_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: project_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.project_roles_id_seq OWNED BY public.project_roles.proj_role_id;


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    proj_id integer NOT NULL,
    name text NOT NULL,
    start date NOT NULL,
    "end" date,
    description text NOT NULL
);


--
-- Name: projects_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.projects_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: projects_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.projects_id_seq OWNED BY public.projects.proj_id;


--
-- Name: skills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.skills (
    skill_id integer NOT NULL,
    name text NOT NULL,
    description text
);


--
-- Name: skills_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.skills_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: skills_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.skills_id_seq OWNED BY public.skills.skill_id;


--
-- Name: system_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_roles (
    system_role_id integer NOT NULL,
    name text NOT NULL
);


--
-- Name: system_roles_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.system_roles_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: system_roles_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.system_roles_id_seq OWNED BY public.system_roles.system_role_id;


--
-- Name: user_x_project_x_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_x_project_x_role (
    "user" integer NOT NULL,
    project_role integer,
    project integer NOT NULL
);


--
-- Name: user_x_skill; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_x_skill (
    "user" integer NOT NULL,
    skill integer NOT NULL
);


--
-- Name: user_x_sys_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_x_sys_role (
    "user" integer NOT NULL,
    system_role integer NOT NULL
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    user_id integer NOT NULL,
    name text NOT NULL,
    surname text NOT NULL,
    patronymic text NOT NULL,
    department integer,
    "position" integer
);


--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: -
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.user_id;


--
-- Name: departments dep_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments ALTER COLUMN dep_id SET DEFAULT nextval('public.departments_id_seq'::regclass);


--
-- Name: permissions perm_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions ALTER COLUMN perm_id SET DEFAULT nextval('public.permissions_id_seq'::regclass);


--
-- Name: positions pos_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.positions ALTER COLUMN pos_id SET DEFAULT nextval('public.positions_id_seq'::regclass);


--
-- Name: project_roles proj_role_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_roles ALTER COLUMN proj_role_id SET DEFAULT nextval('public.project_roles_id_seq'::regclass);


--
-- Name: projects proj_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects ALTER COLUMN proj_id SET DEFAULT nextval('public.projects_id_seq'::regclass);


--
-- Name: skills skill_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skills ALTER COLUMN skill_id SET DEFAULT nextval('public.skills_id_seq'::regclass);


--
-- Name: system_roles system_role_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_roles ALTER COLUMN system_role_id SET DEFAULT nextval('public.system_roles_id_seq'::regclass);


--
-- Name: users user_id; Type: DEFAULT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users ALTER COLUMN user_id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Data for Name: accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.accounts (login, password, email, user_id, active) FROM stdin;
\.
COPY public.accounts (login, password, email, user_id, active) FROM '$$PATH$$/3436.dat';

--
-- Data for Name: departments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.departments (dep_id, name) FROM stdin;
\.
COPY public.departments (dep_id, name) FROM '$$PATH$$/3437.dat';

--
-- Data for Name: permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.permissions (perm_id, table_name, clearance, system_role, action) FROM stdin;
\.
COPY public.permissions (perm_id, table_name, clearance, system_role, action) FROM '$$PATH$$/3439.dat';

--
-- Data for Name: positions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.positions (pos_id, name) FROM stdin;
\.
COPY public.positions (pos_id, name) FROM '$$PATH$$/3441.dat';

--
-- Data for Name: project_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_roles (proj_role_id, name) FROM stdin;
\.
COPY public.project_roles (proj_role_id, name) FROM '$$PATH$$/3443.dat';

--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (proj_id, name, start, "end", description) FROM stdin;
\.
COPY public.projects (proj_id, name, start, "end", description) FROM '$$PATH$$/3445.dat';

--
-- Data for Name: skills; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.skills (skill_id, name, description) FROM stdin;
\.
COPY public.skills (skill_id, name, description) FROM '$$PATH$$/3447.dat';

--
-- Data for Name: system_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_roles (system_role_id, name) FROM stdin;
\.
COPY public.system_roles (system_role_id, name) FROM '$$PATH$$/3449.dat';

--
-- Data for Name: user_x_project_x_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_x_project_x_role ("user", project_role, project) FROM stdin;
\.
COPY public.user_x_project_x_role ("user", project_role, project) FROM '$$PATH$$/3451.dat';

--
-- Data for Name: user_x_skill; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_x_skill ("user", skill) FROM stdin;
\.
COPY public.user_x_skill ("user", skill) FROM '$$PATH$$/3452.dat';

--
-- Data for Name: user_x_sys_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_x_sys_role ("user", system_role) FROM stdin;
\.
COPY public.user_x_sys_role ("user", system_role) FROM '$$PATH$$/3453.dat';

--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (user_id, name, surname, patronymic, department, "position") FROM stdin;
\.
COPY public.users (user_id, name, surname, patronymic, department, "position") FROM '$$PATH$$/3454.dat';

--
-- Name: departments_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.departments_id_seq', 1, false);


--
-- Name: permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.permissions_id_seq', 2, true);


--
-- Name: positions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.positions_id_seq', 1, false);


--
-- Name: project_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.project_roles_id_seq', 1, false);


--
-- Name: projects_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.projects_id_seq', 1, false);


--
-- Name: skills_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.skills_id_seq', 1, false);


--
-- Name: system_roles_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.system_roles_id_seq', 4, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.users_id_seq', 18, true);


--
-- Name: departments departments_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.departments
    ADD CONSTRAINT departments_pk PRIMARY KEY (dep_id);


--
-- Name: positions positions_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.positions
    ADD CONSTRAINT positions_pk PRIMARY KEY (pos_id);


--
-- Name: project_roles project_roles_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_roles
    ADD CONSTRAINT project_roles_pk PRIMARY KEY (proj_role_id);


--
-- Name: projects projects_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pk PRIMARY KEY (proj_id);


--
-- Name: skills skills_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.skills
    ADD CONSTRAINT skills_pk PRIMARY KEY (skill_id);


--
-- Name: user_x_sys_role system_clearance_person_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_x_sys_role
    ADD CONSTRAINT system_clearance_person_key UNIQUE ("user");


--
-- Name: system_roles system_roles_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_roles
    ADD CONSTRAINT system_roles_pk PRIMARY KEY (system_role_id);


--
-- Name: users users_pk; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pk PRIMARY KEY (user_id);


--
-- Name: accounts_email_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX accounts_email_idx ON public.accounts USING btree (email);


--
-- Name: accounts_login_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX accounts_login_idx ON public.accounts USING btree (login);


--
-- Name: permissions_id_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX permissions_id_idx ON public.permissions USING btree (perm_id);


--
-- Name: project_clearance_person_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX project_clearance_person_idx ON public.user_x_project_x_role USING btree ("user", project);


--
-- Name: user_x_skill_user_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX user_x_skill_user_idx ON public.user_x_skill USING btree ("user", skill);


--
-- Name: accounts accounts_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.accounts
    ADD CONSTRAINT accounts_fk FOREIGN KEY (user_id) REFERENCES public.users(user_id) ON DELETE SET NULL;


--
-- Name: permissions permissions_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.permissions
    ADD CONSTRAINT permissions_fk FOREIGN KEY (system_role) REFERENCES public.system_roles(system_role_id) ON UPDATE CASCADE ON DELETE CASCADE;


--
-- Name: user_x_project_x_role project_clearance_fk0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_x_project_x_role
    ADD CONSTRAINT project_clearance_fk0 FOREIGN KEY ("user") REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: user_x_project_x_role project_clearance_fk1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_x_project_x_role
    ADD CONSTRAINT project_clearance_fk1 FOREIGN KEY (project_role) REFERENCES public.project_roles(proj_role_id) ON DELETE SET NULL;


--
-- Name: user_x_project_x_role project_clearance_fk2; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_x_project_x_role
    ADD CONSTRAINT project_clearance_fk2 FOREIGN KEY (project) REFERENCES public.projects(proj_id) ON DELETE CASCADE;


--
-- Name: user_x_skill skill_allocation_fk0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_x_skill
    ADD CONSTRAINT skill_allocation_fk0 FOREIGN KEY ("user") REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: user_x_skill skill_allocation_fk1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_x_skill
    ADD CONSTRAINT skill_allocation_fk1 FOREIGN KEY (skill) REFERENCES public.skills(skill_id) ON DELETE CASCADE;


--
-- Name: user_x_sys_role system_clearance_fk0; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_x_sys_role
    ADD CONSTRAINT system_clearance_fk0 FOREIGN KEY ("user") REFERENCES public.users(user_id) ON DELETE CASCADE;


--
-- Name: user_x_sys_role system_clearance_fk1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_x_sys_role
    ADD CONSTRAINT system_clearance_fk1 FOREIGN KEY (system_role) REFERENCES public.system_roles(system_role_id) ON DELETE CASCADE;


--
-- Name: users users_fk; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_fk FOREIGN KEY (department) REFERENCES public.departments(dep_id) ON DELETE SET NULL;


--
-- Name: users users_fk1; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_fk1 FOREIGN KEY ("position") REFERENCES public.positions(pos_id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

